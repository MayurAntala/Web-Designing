<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>become-a-provider</title>

    <!-- style.php -->
    <?php include("inc/style.php"); ?>
</head>

<body>
    <!-- header.php -->
    <?php include("inc/header.php"); ?>

    <main>
        <!-- Section First start -->
        <div class="first-section bg-01">
            <div class="container-fluid">
                <div class="row">
                    <div
                        class="col-xxl-5 co-xl-5 col-lg-5 col-md-5 col-sm-12 col-12 d-flex flex-column justify-content-center">
                        <div class="header-left p-all pt-20px">
                            <h1 class="h-text1 fw-bolder fs-50px">Earn money while you learn and on-the-go.</h1>

                            <p class="fw-medium fs-18px">Earn money quickly & conveniently while you go to college! Help
                                out your local community & other students with tasks, chores & gigs.</p>
                            <p>

                            <P class="py-5">
                                <button class="rounded-pill text-white bg border fw-medium p-btn fs-18px"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start a task">Start a
                                    Tasks</button>

                                <button
                                    class="rounded-pill text-success border border-success bg-white fw-medium mx-3 p-btn fs-18px"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Free download app!">Download
                                    App</button>
                            </P>
                        </div>
                    </div>

                    <div
                        class="col-xxl-7 co-xl-7 col-lg-7 col-md-7 col-sm-12 col-12 d-flex justify-content-center align-items-center">
                        <div class=" py-3 px-md-5 px-sm-5 hide-768px img-h">
                            <img src="./assets/img/svg/become-main-img.svg" alt="header-image"
                                class="img-contaier img-fluid" data-bs-toggle="tooltip" title="Main image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End -->

        <!-- Section Second start -->
        <div class="second-section">
            <div class="container-fluid">
                <div class="row">
                    <div
                        class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex flex-column justify-content-center align-items-center">
                        <div class="p-all">

                            <h1 class="py-5 fs-36px center-768px text-start">Benefits</h1>

                            <p class="ps-5 fw-bold fs-20px">#1: Local tasks & chores</p>

                            <p class="ps-5 fs-15px">Connect with your fellow students and local community.</p>

                            <p class="ps-5 fw-bold fs-20px">#2: Remote work</p>

                            <p class="ps-5 fs-15px">If you prefer to work remote, check out our gigs like freelance,
                                student
                                consulting, and tutoring.</p>

                            <p class="ps-5 fw-bold fs-20px">#3: Earn money on-the-go</p>

                            <p class="ps-5 fs-15px">When you grab a bite to eat, mention you’re On The Way to cash in
                                nearby Delivery & Carpool orders.</p>
                        </div>
                    </div>

                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
                        <div class="py-5">
                            <img src="./assets/img/group-328.png" alt="header-image" class="img-contaier img-fluid"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Youtube">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End -->

        <!-- Section Third start -->
        <div class="third-section bg-01">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <h1 class="p-all py-5 fs-36px center-768px">How it work</h1>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class=" d-flex justify-content-evenly align-items-center flex-wrap pb-5">
                            <div class="text-center">
                                <img src="./assets/img/svg/finger-touching-tablet-screen-svg.svg" alt=""
                                    class="px-2 py-5 img-fluid s-img-sec3" data-bs-toggle="tooltip"
                                    data-bs-placement="left" title="Fingure Touching Tablate">

                                <p class="fs-20px"><strong>1. Creat a task</strong></p>

                                <p class="fs-15px">Download app, explore task <br>categories, & find a provider for <br>
                                    your needs.</p>
                            </div>

                            <div class="text-center">
                                <!-- <img src="./assets/img/cleaning-tools.png" alt="" class="px-2 py-5 img-fluid s-img-sec3"> -->
                                <img src="./assets/img/svg/cleaning-tools-svg.svg" alt=""
                                    class="px-2 py-5 img-fluid s-img-sec3" data-bs-toggle="tooltip"
                                    data-bs-placement="left" title="Cleaning tool">

                                <p class="fs-20px"><strong>2. Complete task</strong></p>

                                <p class="fs-15px">Follow the app to chat with <br>providers, start & complete
                                    <br>tasks.
                                </p>
                            </div>

                            <div class="text-center">
                                <!-- <img src="./assets/img/card.png" alt="" class="px-2 py-5 img-fluid s-img-sec3"> -->
                                <img src="./assets/img/svg/card-svg.svg" alt="" class="px-2 py-5 img-fluid s-img-sec3"
                                    data-bs-toggle="tooltip" data-bs-placement="left" title="Card">

                                <p class="fs-20px"><strong>Pay Securely br with Stripe</strong></p>

                                <p class="fs-15px">Thoyen partners with Stripe <br>so give you secure payments <br>right
                                    in
                                    the app. </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End -->

        <!-- Section Third start -->
        <div class="third-section pb-5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <h1 class="p-all py-5 fs-36px center-768px">Tasks</h1>
                    </div>
                </div>

                <div class="row p-all"> 
                    <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-6 col-6 w-20">
                        <div class="card py-2 px-2 border border-success my-3 h-352px-01">
                            <div class="text-center">
                                <img src="./assets/img/svg/tasks/pick-up-delivery.svg"
                                    class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                            </div>
                            <div class="card-body text-center">
                                <h5 class="card-title fw-bold">Pick Up & Delivery</h5>
                                <p class="card-text fs-18px">Restaurant</p>
                                <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                                <p class="card-text fw-bold fs-18px">$9.41</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-6 col-6 w-20">
                        <div class="card py-2 px-2 border border-success my-3 h-352px-01">
                            <div class="text-center">
                                <img src="./assets/img/svg/cleaning-tools-svg.svg"
                                    class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                            </div>
                            <div class="card-body text-center">
                                <h5 class="card-title fw-bold">House Cleaning</h5>
                                <p class="card-text fs-18px">Regular</p>
                                <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                                <p class="card-text fw-bold fs-18px">$22.03 - $44.37</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-6 col-6 w-20">
                        <div class="card py-2 px-2 border border-success my-3 h-352px-01">
                            <div class="text-center">
                                <img src="./assets/img/svg/elearning.svg" class="card-img-top img-become w-120px-01 img-fluid"
                                    alt="...">
                            </div>
                            <div class="card-body text-center">
                                <h5 class="card-title fw-bold">Tutoring</h5>
                                <p class="card-text fs-18px">College</p>
                                <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                                <p class="card-text fw-bold fs-18px">$28.83</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-6 col-6 w-20">
                        <div class="card py-2 px-2 border border-success my-3 h-352px-01">
                            <div class="text-center">
                                <img src="./assets/img/svg/elearning.svg" class="card-img-top img-become w-120px-01 img-fluid"
                                    alt="...">
                            </div>
                            <div class="card-body text-center">
                                <h5 class="card-title fw-bold">Tutoring</h5>
                                <p class="card-text fs-18px">High School</p>
                                <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                                <p class="card-text fw-bold fs-18px">$28.83</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-6 col-6 w-20 m-auto">
                        <div class="card py-2 px-2 border border-success my-3 h-352px-01">
                            <div class="text-center">
                                <img src="./assets/img/svg/tasks/cleaning-tools-svg.svg"
                                    class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                            </div>
                            <div class="card-body text-center">
                                <h5 class="card-title fw-bold">House Cleaning</h5>
                                <p class="card-text fs-18px">Regular</p>
                                <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                                <p class="card-text fw-bold fs-18px">$22.03 - $44.37</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <P class="py-2 text-center">
                            <button class="rounded-pill text-white bg border fw-medium p-btn fs-18px"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Explore a task">Explore
                                Tasks</button>
                        </P>
                    </div>
                </div>
            </div>


        </div>
        <!-- End -->

        <!-- Section fourth start -->
        <div class="third-section bg-01 pb-5 p-all">
            <div class="container-fluid">
                <div class="row">
                    <div
                        class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex align-items-center justify-content-between">
                        <div>
                            <h1 class=" py-5 fs-36px center-768px">Q & A</h1>

                        </div>
                        <div>
                            <p class="m-0"><a href="#"
                                    class="link-secondary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover fs-18px">View
                                    Current OMW Providers</a></p>
                        </div>
                    </div>
                </div>

                <div class="row g-0">
                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Is there an app?</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>

                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Will I be safe doing local task?</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>

                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>How will I know what’s required for a task?</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>

                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>How do I price my task?</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>

                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>How do I contact customers?</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>

                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>How will I get paid?</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                </div>
            </div>
            <!-- End -->
        </div>

        <!-- Section five start -->
        <div class="five-section">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <h1 class="p-all pt-5 fs-36px center-768px">Provider Quotes</h1>
                    </div>
                </div>
            </div>
        </div>

        <!-- slider -->
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="main_slider w-slider py-5" style=" margin: auto;">
                        <div class="row slider demo">
                            <div class="col-4 slide_card">
                                <div class="box mx-3 box border border-success border-2 px-30px">
                                    <P class="fs-18px">Meera Mistry</P>

                                    <h6 class="fw-bolder fs-18px">Texas University Student
                                    </h6>

                                    <p class="fs-16px">“It was my first experience - Easy to use
                                        App, friendly Provider who completed the cleaning at a reasonable price.
                                        Highly recommended!”</p>
                                </div>
                            </div>

                            <div class="col-4 slide_card w-slider">
                                <div class="box mx-3 box border border-success border-2 px-30px">
                                    <P class="fs-18px">Savannah Chavez</P>

                                    <h6 class="fw-bolder fs-18px">A&M Student
                                    </h6>

                                    <p class="fs-16px">“Thoyen is such a great app! I have never had a problem on either
                                        side
                                        (customer
                                        or
                                        provider). The Thoyen team is really nice, as well, and...”</p>
                                </div>
                            </div>

                            <div class="col-4 slide_card w-slider">
                                <div class="box mx-3 box border border-success border-2 px-30px">
                                    <P class="fs-18px">Meera Mistry</P>

                                    <h6 class="fw-bolder fs-18px">Texas University Student
                                    </h6>

                                    <p class="fs-16px">“It was my first experience - Easy to use
                                        App, friendly Provider who completed the cleaning at a reasonable price.
                                        Highly recommended!”</p>
                                </div>
                            </div>

                            <div class="col-4 slide_card w-slider">
                                <div class="box mx-3 box border border-success border-2 px-30px">
                                    <P class="fs-18px">Savannah Chavez</P>

                                    <h6 class="fw-bolder fs-18px">A&M Student
                                    </h6>

                                    <p class="fs-16px">“Thoyen is such a great app! I have never had a problem on either
                                        side
                                        (customer
                                        or
                                        provider). The Thoyen team is really nice, as well, and...”</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End -->

        <!-- Section six start -->
        <div class="six-section bg-01 py-5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="d-flex justify-content-between align-items-center">
                            <p class="fs-20px fw-medium px-3 d-flex align-items-center m-0">available in over 400
                                colleges!
                            </p>

                            <button
                                class="rounded-pill text-success border border-success bg-white fw-medium mx-3 p-btn fs-18px"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="school information">Find
                                My School</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End -->

        <!-- Section seven start -->
        <div class="seven-section py-5">
            <div class="container-fluid">
                <div class="row">
                    <div
                        class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex flex-column justify-content-center align-items-center">
                        <div class="d-flex flex-column justify-content-center align-items-center py-5">
                            <h1 class="fs-30px">College students servicing <br>businesses & individuals</h1>
                            <p class="my-5">
                                <button class="rounded-pill bg text-white border-0 fw-medium mx-3 p-btn fs-18px"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sign up">Sign
                                    up</button>

                                <button
                                    class="rounded-pill text-success border border-success bg-white fw-medium mx-3 p-btn fs-18px"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Free download app">Download
                                    App</button>
                            </p>
                        </div>
                    </div>

                    <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
                        <div>
                            <img src="./assets/img/group-93.png" alt="header-image" class="img-contaier img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End -->
    </main>

    <!-- footer.php -->
    <?php include("inc/footer.php"); ?>


    <!-- script.php -->
    <?php include("inc/script.php"); ?>
</body>

</html>