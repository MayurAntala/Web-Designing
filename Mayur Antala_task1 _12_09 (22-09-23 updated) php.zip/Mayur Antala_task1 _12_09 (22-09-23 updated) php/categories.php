<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>categories</title>

    <!-- style.php -->
    <?php include("inc/style.php"); ?>
</head>

<body>

    <!-- header.php -->
    <?php include("inc/header.php"); ?>
    
    <!-- First Section start -->
    <div class="first-section bg-01">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-8 co-xl-8 col-lg-8 col-md-8 col-sm-6 col-4 d-flex align-items-center">
                    <h1 class="p-all py-5 fs-36px m-0">Categories</h1>
                </div>

                <div
                    class="col-xxl-4 co-xl-4 col-lg-4 col-md-4 col-sm-6 col-8 d-flex align-items-center justify-content-end">
                    <input class="form-control me-2 w-50" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-white" type="submit"><span><i class="fa-solid fa-magnifying-glass"
                                style="color: black;"></i></span></button>
                </div>

                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex align-items-center center1">
                    <h4 class="p-all py-3 fs-20px m-0">Remote</h4>
                </div>
            </div>
        </div>

        <div class="container-fluid p-all">
            <div class="row">
                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/college.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-10px">

                                <img src="./assets/img/svg/college-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-10px">

                                <p class="text-success text-center fw-semibold fs-18px">Advice for High
                                    <br>Schoolers
                                </p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/money.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/money-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Freelance</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/reading.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-10px">

                                <img src="./assets/img/svg/reading-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-10px">

                                <p class="text-success text-center fw-semibold fs-18px">Student <br>
                                    Consulting</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/elearning.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/elearning-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Tutoring</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20 sec-fifth-img-center">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/pencil.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/pencil-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Name Your Task</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- End -->

    <!-- Second Section start -->
    <div class="second-section bg-01">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex align-items-center center1">
                    <h4 class="p-all py-3 fs-20px">Local</h4>
                </div>
            </div>
        </div>

        <!-- Local image section -->
        <div class="container-fluid p-all">
            <div class="row">
                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/car.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-10px">

                                <img src="./assets/img/svg/categories/car-white1.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-10px">

                                <p class="text-success text-center fw-semibold fs-18px">Advice for High
                                    <br>Schoolers
                                </p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/cleaning-tools.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/categories/cleaning-tools-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Freelance</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/balloons.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-10px">

                                <img src="./assets/img/svg/categories/balloons-whtie.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-10px">

                                <p class="text-success text-center fw-semibold fs-18px">Student <br>
                                    Consulting</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/hammering.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/categories/hammering-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Tutoring</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/technical-support.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/categories/technical-support-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Name Your Task</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/washing-machine.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-10px">

                                <img src="./assets/img/svg/categories/washing-machine-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-10px">

                                <p class="text-success text-center fw-semibold fs-18px">Advice for High
                                    <br>Schoolers
                                </p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/box.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/categories/box-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Freelance</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/jack-o-lantern.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-10px">

                                <img src="./assets/img/svg/categories/jack-o-lantern-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-10px">

                                <p class="text-success text-center fw-semibold fs-18px">Student <br>
                                    Consulting</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/broom.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/categories/broom-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Tutoring</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20 sec-fifth-img-center">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/pencil.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/categories/pencil-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Name Your Task</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Third Section start -->
    <div class="third-section bg-01 pb-5">
        <div class="container-fluid">
            <div class="row">
                <div
                    class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 d-flex align-items-center justify-content-between">
                    <div>
                        <h4 class="p-all py-3 fs-20px m-0 m-575px">On My Way</h4>
                    </div>
                    <div>
                        <p class="m-0"><a href="#"
                                class="link-secondary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover fs-18px">View
                                Current OMW Providers</a></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- On My Way image section -->
        <div class="container-fluid p-all">
            <div class="row">
                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/car-sharing.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-10px">

                                <img src="./assets/img/svg/categories/car-sharing-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-10px">

                                <p class="text-success text-center fw-semibold fs-18px">Advice for High
                                    <br>Schoolers
                                </p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="my-3 text-center m-575px">
                        <!-- Image toogle -->
                        <div class="card card-category">
                            <div class="card-body">

                                <img src="./assets/img/svg/categories/shopping-bag.svg" alt="logo-img"
                                    class="logo-1 img-fluid s-img-sec5 p-20px">

                                <img src="./assets/img/svg/categories/shopping-bag-white.svg" alt="logo-img"
                                    class="logo-2 img-fluid s-img-sec5 p-20px">

                                <p class="text-success text-center fw-semibold fs-18px">Freelance</p>
                            </div>
                        </div>
                        <!-- End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- footer.php -->
    <?php include("inc/footer.php"); ?>


    <!-- script.php -->
    <?php include("inc/script.php"); ?>

</body>

</html>