<!-- Section footer start -->
<footer class="footer-section py-5 bg-dark">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                <div class="sec-eleven d-flex flex-row justify-content-between align-items-center flex2">
                    <div class="logo p-4 text-white fw-bold">
                        <h1 class="fs-38px">THOYEN</h1>
                    </div>
                    <div class="text-white p-4 fs-18px">
                        <p>
                            About Us
                        </p>

                        <p>Our Assurance</p>

                        <p>Contact us</p>
                    </div>
                </div>
            </div>

            <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                <div class="d-flex flex-row justify-content-between align-items-center flex2">
                    <div class=" sec-eleven text-white p-4 fs-18px">
                        <p>
                            Tearm of Use
                        </p>

                        <p>Privacy Policy</p>

                        <p>FAQs</p>
                    </div>

                    <div class="logo p-4">
                        <img src="./assets/img/group-352.png" alt="" class="w-social-icon">
                    </div>

                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End -->