<!-- Header Section -->
<header style="position: sticky; top: 0; z-index: 99;">
    <!-- Navigation bar logo  -->
    <div class="container-fluid border">
        <div class="row bg-white">
            <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-3 col-3">
                <div class="logo d-flex align-items-center h-100 py-3 p-all">
                    <a href="index.php">
                        <img src="./assets/img/logo-thoyen.png" alt="" class="w-logo">
                    </a>
                </div>
            </div>

            <div class="col-xxl-9 co-xl-9 col-lg-9 col-md-9 col-sm-9 col-9">
                <div class="d-flex justify-content-end align-items-center py-3">
                    <!-- <span class="border-end px-3 border-success fw-medium fs-18px hide-462px">Become a
                        provider</span> -->
                    <span class="border-end px-3 border-success fw-medium fs-18px hide-462px">
                        <a class="nav-link active link-dark" aria-current="page" href="become-a-provider.php">Become a
                            provider</a></span>

                    <span class="px-3"><a href="#"
                            class="link-body-emphasis link-offset-2 link-underline-opacity-0 link-underline-opacity-75-hover fw-medium fs-18px">Login</a>
                    </span>

                    <button class="rounded-pill bg text-white border-0 fw-medium p-btn fs-18px">Sign
                        up</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu Section -->
    <section class="menu-section">
        <div class="container-fluid border">
            <div class="row bg">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div
                        class="d-flex flex-row justify-content-between align-items-start flex-row-reverse fs-18px fw-medium">
                        <nav class="navbar navbar-expand-lg">
                            <div class="container">
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"
                                    aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"></span>
                                </button>

                                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                    <ul class="navbar-nav text-dark">
                                        <li class="nav-item">
                                            <a class="nav-link active link-dark" aria-current="page"
                                                href="categories.php">Categories</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link link-dark" href="provider.php">Providers</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link link-dark" href="tasks.php">Tasks</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link link-dark" href="market-place.php">Marketplace</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link link-dark nav1-hide-992px-min" href="#">Download
                                                Free App!</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </nav>

                        <div class="menu-right d-flex justify-content-start align-items-center w-100 h-20px p-all">
                            <span>
                                <a href="#"
                                    class="link-body-emphasis link-offset-2 link-underline-opacity-0 link-underline-opacity-75-hover fw-medium fs-18px fw-medium nav2-hide-992px-max">Download
                                    Free App!</a>
                            </span>

                            <span>
                                <!-- <img src="./assets/img/group-321.png" alt="" class="w-goup-321 px-2"> -->
                                <a href="" data-bs-toggle="tooltip" title="Ply store"><img
                                        src="./assets/img/group-321.png" alt="" class="w-goup-321 px-2"></a>
                            </span>

                            <span>
                                <!-- <img src="./assets/img/group-322.png" alt="" class="w-goup-321 px-2"> -->
                                <a href="" data-bs-toggle="tooltip" title="Apple"><img src="./assets/img/group-322.png"
                                        alt="" class="w-goup-321 px-2"></a>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</header>
<!-- End -->