<!-- Slick slider js-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="./Fully-Responsive-Flexible-jQuery-Carousel-Plugin-slick/slick/slick.min.js"></script>

<!-- Boostrap 5.3.1 -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>


<script>
    $(document).ready(function () {
        $('.demo').slick({
            autoplay: true,
            arrow: true,
            autoplaySpeed: 3000,
            slidesToShow: 2,
            dots: true,
            responsive: [{
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    dots: false,

                }


            }]

        });
    });
</script>

<script>
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
</script>