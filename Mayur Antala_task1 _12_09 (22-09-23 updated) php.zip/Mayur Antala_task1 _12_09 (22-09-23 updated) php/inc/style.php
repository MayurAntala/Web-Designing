<!-- Font awsome icon cdn -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
    integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Bootstrap 5.3.1 css -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">

<!-- Slick slider css-->
<link rel="stylesheet" href="./Fully-Responsive-Flexible-jQuery-Carousel-Plugin-slick/slick/slick.css">
<link rel="stylesheet" href="./Fully-Responsive-Flexible-jQuery-Carousel-Plugin-slick/slick/slick-theme.css">

<!-- Custome css -->
<link rel="stylesheet" href="./assets/css/style.css">
<link rel="stylesheet" href="./assets/css/mediaquery.css">

<!-- market place css -->
<link rel="stylesheet" href="./assets/css/market-place.css">

<!-- Become a provider css -->
<link rel="stylesheet" href="./assets/css/become-a-provider.css">

 <!-- Tasks css -->
 <link rel="stylesheet" href="./assets/css/tasks.css">

 <!-- Providers css -->
 <link rel="stylesheet" href="./assets/css/providers.css">