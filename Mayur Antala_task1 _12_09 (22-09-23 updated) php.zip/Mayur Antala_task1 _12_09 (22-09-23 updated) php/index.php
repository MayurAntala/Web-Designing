<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thoyen</title>

    <!-- style.php -->
    <?php include("inc/style.php"); ?>

</head>

<body>
    <!-- header.php -->
    <?php include("inc/header.php"); ?>

    <!-- Section First start -->
    <div class="first-section bg-01">
        <div class="container-fluid">
            <div class="row">
                <div
                    class="col-xxl-5 co-xl-5 col-lg-5 col-md-5 col-sm-12 col-12 d-flex flex-column justify-content-center">
                    <div class="header-left p-all pt-20px">
                        <h1 class="h-text1 fw-bolder fs-50px">Tasks, chores, & gigs? <br>
                            Consider it done.</h1>

                        <p class="fw-medium fs-18px">Talented, hardworking students from your top-ranked
                            colleges are
                            here to help with your
                            local & remote tasks at unbeatable prices.</p>
                        <p>

                        <P class="py-5">
                            <button class="rounded-pill text-white bg border fw-medium p-btn fs-18px-index"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Explore">Explore
                                Tasks</button>

                            <button
                                class="rounded-pill text-success border border-success bg-white fw-medium mx-3 p-btn fs-18px-index"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Free download app!">Download
                                App</button>
                        </P>
                    </div>
                </div>

                <div class="col-xxl-7 co-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
                    <div class=" py-3 px-md-5 px-sm-5 hide-768px">
                        <!-- <img src="./assets/img/group-75.png" alt="header-image" class="img-contaier img-fluid"> -->
                        <a href="" data-bs-toggle="tooltip" title="Main image"><img src="./assets/img/group-75.png"
                                alt="header-image" class="img-contaier img-fluid"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section Second start -->
    <div class="second-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="py-5">
                        <h1 class="fs-36px p-all center-768px">Popular on toyen</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div
                class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-evenly flex-wrap">
                <div>
                    <div class="text-center">
                        <img src="./assets/img/svg/group-236.svg" alt=""
                            class="border rounded-circle px-2 py-3 border-success img-fluid s-img-sec2"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Tutorial">
                    </div>

                    <div class="text-center my-3">
                        <p class="fs-15px fw-medium"><strong class="fs-18px"> For:</strong> College, High School,
                            <br>
                            Middle School,
                            Elementary <br> School, & Adult/Community
                        </p>
                    </div>
                </div>

                <div>
                    <div class="text-center">
                        <img src="./assets/img/svg/group-235-svg.svg" alt=""
                            class="border rounded-circle px-2 py-3 border-success img-fluid s-img-sec2"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Freelance">
                    </div>

                    <div class="text-center my-3">
                        <p class="fs-15px fw-medium"><strong class="fs-18px"> For:</strong> College, High School,
                            <br>
                            Middle School,
                            Elementary <br> School, & Adult/Community
                        </p>
                    </div>
                </div>

                <div class="pb-5">
                    <div class="text-center">
                        <img src="./assets/img/svg/group-233-svg.svg" alt=""
                            class="border rounded-circle px-2 py-3 border-success img-fluid s-img-sec2"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Student Consulting">
                    </div>

                    <div class="text-center my-3">
                        <p class="fs-15px fw-medium"><strong class="fs-18px"> For:</strong> College, High School,
                            <br>
                            Middle School,
                            Elementary <br> School, & Adult/Community
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section third start -->
    <div class="third-section bg-01">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h1 class="p-all py-5 fs-36px center-768px">Why Thoyen?</h1>
                </div>

                <div
                    class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex flex-column justify-content-center align-items-center">
                    <div class="p-all">
                        <p class="fw-bold fs-20px">#1: Keep it local for tasks & chores</p>

                        <p class="fs-15px">Connect with local college students with great skills & talent for the
                            quality job you need.</p>

                        <p class="fw-bold fs-20px">#1: Keep it local for tasks & chores</p>

                        <p class="fs-15px">Connect with local college students with great skills & talent for the
                            quality job you need.</p>

                        <p class="fw-bold fs-20px">#1: Keep it local for tasks & chores</p>

                        <p class="fs-15px">Connect with local college students with great skills & talent for the
                            quality job you need.</p>

                        <p class="fw-bold fs-20px">#1: Keep it local for tasks & chores</p>

                        <p class="fs-15px">Connect with local college students with great skills & talent for the
                            quality job you need.</p>
                    </div>
                </div>

                <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
                    <div class="pb-5">
                        <img src="./assets/img/group-328.png" alt="header-image" class="img-contaier img-fluid"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Youtube">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section forth start -->
    <div class="third-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h1 class="p-all py-5 fs-36px center-768px">How it work</h1>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class=" d-flex justify-content-evenly align-items-center flex-wrap pb-5">
                        <div class="text-center">
                            <img src="./assets/img/svg/finger-touching-tablet-screen-svg.svg" alt=""
                                class="px-2 py-5 img-fluid s-img-sec3" data-bs-toggle="tooltip" data-bs-placement="left"
                                title="Fingure Touching Tablate">

                            <p class="fs-20px"><strong>1. Creat a task</strong></p>

                            <p class="fs-15px">Download app, explore task <br>categories, & find a provider for <br>
                                your needs.</p>
                        </div>

                        <div class="text-center">
                            <!-- <img src="./assets/img/cleaning-tools.png" alt="" class="px-2 py-5 img-fluid s-img-sec3"> -->
                            <img src="./assets/img/svg/cleaning-tools-svg.svg" alt=""
                                class="px-2 py-5 img-fluid s-img-sec3" data-bs-toggle="tooltip" data-bs-placement="left"
                                title="Cleaning tool">

                            <p class="fs-20px"><strong>2. Complete task</strong></p>

                            <p class="fs-15px">Follow the app to chat with <br>providers, start & complete <br>tasks.
                            </p>
                        </div>

                        <div class="text-center">
                            <!-- <img src="./assets/img/card.png" alt="" class="px-2 py-5 img-fluid s-img-sec3"> -->
                            <img src="./assets/img/svg/card-svg.svg" alt="" class="px-2 py-5 img-fluid s-img-sec3"
                                data-bs-toggle="tooltip" data-bs-placement="left" title="Card">

                            <p class="fs-20px"><strong>Pay Securely br with Stripe</strong></p>

                            <p class="fs-15px">Thoyen partners with Stripe <br>so give you secure payments <br>right in
                                the app. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section fifth start -->
    <div class="fifth-section bg-01" id="sec-05">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-8 co-xl-8 col-lg-8 col-md-8 col-sm-6 col-5 d-flex align-items-center">
                    <h1 class="p-all py-5 fs-36px m-0">Categories</span></h1>
                </div>

                <div class="col-xxl-4 co-xl-4 col-lg-4 col-md-4 col-sm-6 col-7">
                    <div class="p-sec-five d-flex justify-content-evenly">
                        <nav>
                            <div class="nav nav-underline" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                                    aria-selected="true">
                                    <a href="#sec-05" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pg-01"
                                        class="text-decoration-none fw-medium">Remote</a>
                                </button>

                                <button class="nav-link" id="sec-05 nav-profile-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile"
                                    aria-selected="false">
                                    <a href="#sec-05" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pg-02"
                                        class="text-decoration-none fw-medium">Local</a>
                                </button>

                                <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact"
                                    aria-selected="false">
                                    <a href="#sec-05" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pg-03"
                                        class="text-decoration-none fw-medium">On My Way</a>
                                </button>


                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="tab-content" id="nav-tabContent">
                <!-- Start -->
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
                    tabindex="0">
                    <!-- Remote -->
                    <div class="row">
                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/college.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-10px">

                                        <img src="./assets/img/svg/college-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-10px">

                                        <p class="text-success text-center fw-semibold fs-18px">Advice for High
                                            <br>Schoolers
                                        </p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/money.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/money-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Freelance</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/reading.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-10px">

                                        <img src="./assets/img/svg/reading-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-10px">

                                        <p class="text-success text-center fw-semibold fs-18px">Student <br>
                                            Consulting</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/elearning.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/elearning-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Tutoring</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20 sec-fifth-img-center">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/pencil.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/pencil-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Name Your Task</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="pb-5"></div>
                    </div>
                </div>

                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"
                    tabindex="0">
                    <!-- Local -->
                    <div class="row">
                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/pencil.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/pencil-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Name Your Task
                                        </p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/elearning.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/elearning-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Tutorial</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/money.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/money-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Freelance</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/reading.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-10px">

                                        <img src="./assets/img/svg/reading-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-10px">

                                        <p class="text-success text-center fw-semibold fs-18px">Student <br>Consulting
                                        </p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20 sec-fifth-img-center">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/college.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-10px">

                                        <img src="./assets/img/svg/college-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-10px">

                                        <p class="text-success text-center fw-semibold fs-18px">Advice for High
                                            <br>Schoolers
                                        </p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="pb-5"></div>
                    </div>
                </div>

                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"
                    tabindex="0">
                    <!-- On My Way -->
                    <div class="row">
                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/reading.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-10px">

                                        <img src="./assets/img/svg/reading-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-10px">

                                        <p class="text-success text-center fw-semibold fs-18px">Student
                                            <br>Consulting
                                        </p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/college.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-10px">

                                        <img src="./assets/img/svg/college-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-10px">

                                        <p class="text-success text-center fw-semibold fs-18px">Advice for High
                                            <br>Schoolers
                                        </p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/money.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/money-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Freelance</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/elearning.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/elearning-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Tutoring</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20 sec-fifth-img-center">
                            <div class="my-3 text-center m-575px">
                                <!-- Image toogle -->
                                <div class="card card-category">
                                    <div class="card-body">

                                        <img src="./assets/img/svg/pencil.svg" alt="logo-img"
                                            class="logo-1 img-fluid s-img-sec5 p-20px">

                                        <img src="./assets/img/svg/pencil-white.svg" alt="logo-img"
                                            class="logo-2 img-fluid s-img-sec5 p-20px">

                                        <p class="text-success text-center fw-semibold fs-18px">Name Your Task</p>
                                    </div>
                                </div>
                                <!-- End -->
                            </div>
                        </div>

                        <div class="pb-5"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section six start -->
    <div class="six-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-9 co-xl-9 col-lg-9 col-md-9 col-sm-6 col-6 d-flex align-items-center">
                    <h1 class="p-all py-5 fs-36px">Market Place</h1>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="p-sec-five d-flex justify-content-evenly" id="three">
                        <ul class="nav nav-underline" id="two">
                            <li class="nav-item">
                                <a class="nav-link active link-body-emphasis link-offset-2 link-underline-opacity-100 link-underline-opacity-75-hover fw-bold fs-20px"
                                    aria-current="page" href="#three" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Pg-01">For Sale</a>

                            </li>
                            <li class="nav-item">
                                <a class="nav-link link-body-emphasis link-offset-2 link-underline-opacity-0 link-underline-opacity-75-hover fs-20px"
                                    aria-current="page" href="#three" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Pg-02">Wishlist</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="py-2 m-575px">
                        <div class="card card2">
                            <img src="./assets/img/pen.png" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Pen<br> $4.42</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/watch.png" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Clock<br>$44.20 </h5>
                                <p class="card-text fs-18px">Delivery</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/books.png" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Textbooks<br> $5.42</h5>
                                <p class="card-text fs-18px">$44.20</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/pencils.png" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Pencil Pack<br> $5.45</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-2 col-md-2 col-sm-4 col-12 w-20 sec-fifth-img-center">
                    <div class="pt-2 pb-5 m-575px">
                        <div class="card">
                            <img src="./assets/img/cleaner.png" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Rake <br> $11.05</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section seven start -->
    <div class="seven-section bg-01 pb-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h1 class="p-all py-5 fs-36px center-768px">Benifits</h1>
                </div>
                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="sec-six-one border border-success text-center bg-white m-575px">
                        <div class="sec-seven-img-sizes p-10px">
                            <img src="./assets/img/svg/satisfaction.svg" alt="" class="img-contaier">
                        </div>
                        <p class="text-success text-center fw-semibold fs-18px">Advice for High <br>Schoolers</p>
                    </div>
                    <p class="text-center py-2 fs-16px">Or your money back!</p>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="sec-six-one border border-success text-center bg-white m-575px">
                        <div class="sec-seven-img-sizes p-10px">
                            <img src="./assets/img/svg/shield.svg" alt="" class="img-contaier">
                        </div>
                        <p class="text-success text-center fw-semibold fs-18px">Safety & Security<br>Build Into the
                            App</p>
                    </div>
                    <p class="text-center py-2 fs-16px">Emergency police button, <br>electronic payments,
                        <br>secure communication. <br>
                        All on the app.
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="sec-six-one border border-success text-center bg-white m-575px">
                        <div class="sec-seven-img-sizes p-20px">
                            <!-- <img src="./assets/img/rate.png" alt="" class="img-contaier"> -->
                            <img src="./assets/img/svg/rate.svg" alt="" class="img-contaier">
                        </div>
                        <p class="text-success text-center fw-semibold fs-18px">Great Features</p>
                    </div>
                    <p class="text-center py-2 fs-16px">Book instantly, track work <br>progress, rate providers &
                        <br>keep track of your history.
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="sec-six-one border border-success text-center bg-white m-575px">
                        <div class="sec-seven-img-sizes p-20px">
                            <img src="./assets/img/svg/promotion.svg" alt="" class="img-contaier">
                        </div>
                        <p class="text-success text-center fw-semibold fs-18px">No Gimmicks</p>
                    </div>
                    <p class="text-center py-2 fs-16px">Our app is free & easy to use. <br>Get straight to the task!</p>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section eight start -->
    <div class="eight-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h1 class="p-all pt-5 fs-36px center-768px">Customer Reviews</h1>
                </div>
            </div>
        </div>
    </div>

    <!-- slider -->
    <div class="container">
        <div class="row">
            <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="main_slider w-slider py-5" style=" margin: auto;">
                    <div class="row slider demo">
                        <div class="col-4 slide_card">
                            <div class="box mx-3 box border border-success border-2 px-30px">
                                <P class="fs-18px">Meera Mistry</P>

                                <h6 class="fw-bolder fs-18px">Texas University Student
                                </h6>

                                <p class="fs-16px">“It was my first experience - Easy to use
                                    App, friendly Provider who completed the cleaning at a reasonable price.
                                    Highly recommended!”</p>
                            </div>
                        </div>

                        <div class="col-4 slide_card w-slider">
                            <div class="box mx-3 box border border-success border-2 px-30px">
                                <P class="fs-18px">Savannah Chavez</P>

                                <h6 class="fw-bolder fs-18px">A&M Student
                                </h6>

                                <p class="fs-16px">“Thoyen is such a great app! I have never had a problem on either
                                    side
                                    (customer
                                    or
                                    provider). The Thoyen team is really nice, as well, and...”</p>
                            </div>
                        </div>

                        <div class="col-4 slide_card w-slider">
                            <div class="box mx-3 box border border-success border-2 px-30px">
                                <P class="fs-18px">Meera Mistry</P>

                                <h6 class="fw-bolder fs-18px">Texas University Student
                                </h6>

                                <p class="fs-16px">“It was my first experience - Easy to use
                                    App, friendly Provider who completed the cleaning at a reasonable price.
                                    Highly recommended!”</p>
                            </div>
                        </div>

                        <div class="col-4 slide_card w-slider">
                            <div class="box mx-3 box border border-success border-2 px-30px">
                                <P class="fs-18px">Savannah Chavez</P>

                                <h6 class="fw-bolder fs-18px">A&M Student
                                </h6>

                                <p class="fs-16px">“Thoyen is such a great app! I have never had a problem on either
                                    side
                                    (customer
                                    or
                                    provider). The Thoyen team is really nice, as well, and...”</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section nine start -->
    <div class="nine-section bg-01 py-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="fs-20px fw-medium px-3 d-flex align-items-center m-0">available in over 400 colleges!
                        </p>

                        <button
                            class="rounded-pill text-success border border-success bg-white fw-medium mx-3 p-btn fs-18px"
                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="school information">Find
                            My School</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- Section ten start -->
    <div class="nine-section py-5">
        <div class="container-fluid">
            <div class="row">
                <div
                    class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex flex-column justify-content-center align-items-center">
                    <div class="d-flex flex-column justify-content-center align-items-center py-5">
                        <h1 class="fs-30px">College students servicing <br>businesses & individuals</h1>
                        <p class="my-5">
                            <button class="rounded-pill bg text-white border-0 fw-medium mx-3 p-btn fs-18px"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sign up">Sign
                                up</button>

                            <button
                                class="rounded-pill text-success border border-success bg-white fw-medium mx-3 p-btn fs-18px"
                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Free download app">Download
                                App</button>
                        </p>
                    </div>
                </div>

                <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
                    <div>
                        <img src="./assets/img/group-93.png" alt="header-image" class="img-contaier img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- footer.php -->
    <?php include("inc/footer.php"); ?>


    <!-- script.php -->
    <?php include("inc/script.php"); ?>
    
</body>

</html>