<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>

    <style>
        .card, .card-body-01{
            border-radius: 18px !important;
        }
    </style>
    <!-- style.php -->
    <?php include("inc/style.php"); ?>

</head>

<body>

    <!-- header.php -->
    <?php include("inc/header.php"); ?>

    <!-- First Section start -->
    <div class="first-section bg-01">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-4 co-xl-4 col-lg-4 col-md-4 col-sm-4 col-12 d-flex align-items-center center1">
                    <h1 class="p-all py-5 fs-36px m-0">Market place</h1>
                </div>
                <div class="col-xxl-4 co-xl-4 col-lg-4 col-md-4 col-sm-4 col-6">
                    <div class="p-sec-five" id="three">
                        <ul class="nav nav-underline d-flex justify-content-evenly" id="two">
                            <li class="nav-item">
                                <a class="nav-link active link-body-emphasis link-offset-2 link-underline-opacity-100 link-underline-opacity-75-hover fw-bold fs-20px"
                                    aria-current="page" href="#three" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Pg-01">For Sale</a>

                            </li>
                            <li class="nav-item">
                                <a class="nav-link link-body-emphasis link-offset-2 link-underline-opacity-0 link-underline-opacity-75-hover fs-20px"
                                    aria-current="page" href="#three" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Pg-02">Wishlist</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div
                    class="col-xxl-4 co-xl-4 col-lg-4 col-md-4 col-sm-4 col-6 d-flex align-items-center justify-content-end">
                    <input class="form-control me-2 w-50" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-white" type="submit"><span><i class="fa-solid fa-magnifying-glass"
                                style="color: black;"></i></span></button>
                </div>

                <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 d-flex align-items-center ">
                    <div class="p-all d-flex align-items-center">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Sort By</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                </div>

                <div
                    class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 center1 d-flex align-items-center justify-content-end">
                    <div class="tasks-right-chk px-3 fs-20px d-flex align-items-center">
                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" class="mx-2">
                        <label for="vehicle1">Delivery Only</label><br>
                    </div>

                    <div class="tasks-right-chk fs-20px d-flex justify-content-center">
                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" class="mx-2">
                        <label for="vehicle1" class="abc">Pick Up</label><br>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid p-all py-5">
            <div class="row">
                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card card2">
                            <img src="./assets/img/svg/pen.svg" class="card-img-top" alt="...">
                            <div class="card-body card-body-01 text-center">
                                <h5 class="card-title fs-20px">Pen<br> $4.42</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/watch.svg" class="card-img-top" alt="...">
                            <div class="card-body card-body-01 text-center">
                                <h5 class="card-title fs-20px">Clock<br>$44.20 </h5>
                                <p class="card-text fs-18px">Delivery</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/books.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Textbooks<br> $5.42</h5>
                                <p class="card-text fs-18px">$44.20</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/pencils.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Pencil Pack<br> $5.45</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card card2">
                            <img src="./assets/img/cleaner.png" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Pen<br> $4.42</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/rectangle-26-1.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Clock<br>$44.20 </h5>
                                <p class="card-text fs-18px">Delivery</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/rectangle-26-2.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Textbooks<br> $5.42</h5>
                                <p class="card-text fs-18px">$44.20</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/rectangle-26-3.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Pencil Pack<br> $5.45</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card card2">
                            <img src="./assets/img/svg/rectangle-26-4.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Pen<br> $4.42</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/rectangle-26-5.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Clock<br>$44.20 </h5>
                                <p class="card-text fs-18px">Delivery</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/rectangle-26-6.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Textbooks<br> $5.42</h5>
                                <p class="card-text fs-18px">$44.20</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="py-2 m-575px">
                        <div class="card">
                            <img src="./assets/img/svg/rectangle-26-7.svg" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h5 class="card-title fs-20px">Pencil Pack<br> $5.45</h5>
                                <p class="card-text fs-18px">Pick Up</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
                <nav aria-label="Page navigation example">
                    <ul class="pagination py-3 my-5">
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- footer.php -->
    <?php include("inc/footer.php"); ?>


    <!-- script.php -->
    <?php include("inc/script.php"); ?>

</body>

</html>