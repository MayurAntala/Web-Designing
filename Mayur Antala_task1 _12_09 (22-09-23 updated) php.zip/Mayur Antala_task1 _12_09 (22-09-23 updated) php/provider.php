<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Providers HTML</title>

    <!-- style.php -->
    <?php include("inc/style.php"); ?>

</head>

<body>
    <!-- header.php -->
    <?php include("inc/header.php"); ?>

    <!-- First Section start -->
    <div class="first-section bg-01">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-8 co-xl-8 col-lg-8 col-md-8 col-sm-6 col-4 d-flex align-items-center">
                    <h1 class="py-5 p-all fs-36px m-0">Providers</h1>
                </div>

                <div
                    class="col-xxl-4 co-xl-4 col-lg-4 col-md-4 col-sm-6 col-8 d-flex align-items-center justify-content-end">
                    <input class="form-control w-50" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-search btn-outline-white" type="submit"><span><i
                                class="fa-solid fa-magnifying-glass" style="color: black;"></i></span></button>
                </div>
            </div>

            <div class="row sec-first">
                <div class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 d-flex align-items-center ">
                    <div class="pe-3 p-all d-flex align-items-center py-3">
                        <select class="form-select form-pro s-form-prov" aria-label="Default select example">
                            <option selected>Categories</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>

                    <div class="d-flex align-items-center">
                        <select class="form-select form-pro s-form-prov" aria-label="Default select example">
                            <option selected>Sort By</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                </div>

                <div
                    class="col-xxl-6 co-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 center1 d-flex align-items-center justify-content-end flex-575px-pro">
                    <div class="tasks-right-chk fs-20px d-flex align-items-center">
                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" class="me-2 s-scale-2">
                        <label for="vehicle1">Remote Only</label><br>
                    </div>

                    <div class="tasks-right-chk px-2 fs-20px d-flex justify-content-center">
                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" class="mx-2 s-scale-2">
                        <label for="vehicle1" class="abc">Local Only</label><br>
                    </div>

                    <div class="tasks-right-chk fs-20px d-flex justify-content-center">
                        <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" class="mx-2 s-scale-2">
                        <label for="vehicle1" class="abc">On My Way Only</label><br>
                    </div>
                </div>
            </div>

        </div>

        <div class="container-fluid p-all">
            <div class="row">
                <div class="col-xxl-10 co-xl-10 col-lg-9 col-md-12 col-sm-12 col-12">
                    <div class="row">
                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-1.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-2.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-3.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-4.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-5.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-6.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-7.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-8.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-9.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-10.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-11.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                            <div class="card py-4 px-2 border-grad my-3 h-380px-01">
                                <div class="text-center">
                                    <img src="./assets/img/svg/provide/ellipse-12.svg"
                                        class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                                </div>
                                <div class="card-body text-center" style="position: relative;">
                                    <h5 class="card-title fw-bold">Allie J</h5>
                                    <p class="card-text fs-18px">ASU Student</p>
                                    <p class="card-text text-body-secondary fs-18px">Tasks:
                                        Carpool,<br> Freelance, Pick Up & Delivery...</p>
                                    <div class="d-flex justify-content-evenly align-items-center">
                                        <p>
                                            <img src="./assets/img/svg/provide/star-4.svg" alt="">
                                        </p>
                                        <p class="fs-18px">5.0</p>
                                        <p class="text-body-secondary fs-18px">45 Reviews</p>
                                    </div>
                                    <p class="card-text fw-bold fs-18px"><a href="" class="text-dark">See More</a></p>
                                    <p>
                                        <img src="./assets/img/svg/provide/heart.svg" alt="" class="pos-heart">
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-2 co-xl-2 col-lg-3 col-md-12 col-sm-12 col-12">
                    <div class="row">
                        <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-6 col-sm-12 col-12 m-auto">
                            <div class="card py-2 px-2 border-grad border-4 my-3 py-5">
                                <div class="card-body text-center" style="position: relative;">
                                    <p class="card-title fw-medium lh-40px text-body-emphasis fs-32px-pro">Want to chat
                                        <br>with
                                        a provider?
                                    </p>
                                    <button
                                        class="rounded-pill bg text-white border-0 fw-medium p-btn fs-18px my-3">Sign
                                        up</button>
                                    <p class="card-text fs-18px m-0">Or</p>
                                    <p><a class="link-opacity-100 fs-20px text-green1 fw-bold" href="#">Login</a></p>
                                    <p class="card-text fs-18px fs-22px-pro">Download the app! <br>Free on <span
                                            class="text-grad fw-bold">iOS</span> and <br><span
                                            class="text-grad fw-bold">Android</span>.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- footer.php -->
    <?php include("inc/footer.php"); ?>


    <!-- script.php -->
    <?php include("inc/script.php"); ?>
</body>

</html>