<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks 2</title>

    <!-- style.php -->
    <?php include("inc/style.php"); ?>

</head>

<body>
    <!-- header.php -->
    <?php include("inc/header.php"); ?>

    <!-- Section First -->
    <div class="third-section pb-5 p-all">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h1 class="py-5 fs-36px center-768px">Tasks</h1>
                </div>
            </div>

            <div class="row">
                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/tasks/pick-up-delivery.svg"
                                class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Pick Up & Delivery</h5>
                            <p class="card-text fs-18px">Restaurant</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$9.41</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/cleaning-tools-svg.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">House Cleaning</h5>
                            <p class="card-text fs-18px">Regular</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$22.03 - $44.37</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/elearning.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Tutoring</h5>
                            <p class="card-text fs-18px">College</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$28.83</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/elearning.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Tutoring</h5>
                            <p class="card-text fs-18px">High School</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$28.83</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/tasks/cleaning-tools-svg.svg"
                                class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">House Cleaning</h5>
                            <p class="card-text fs-18px">Regular</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$22.03 - $44.37</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/tasks/pick-up-delivery.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Pick Up & Delivery</h5>
                            <p class="card-text fs-18px">Restaurant</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">Earnings: $9.41</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/tasks/pick-up-delivery.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Pick Up & Delivery</h5>
                            <p class="card-text fs-18px">Restaurant</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">Earnings: $9.41</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/cleaning-tools-svg.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">House Cleaning</h5>
                            <p class="card-text fs-18px">Regular</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$22.03 - $44.37</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/tasks/pick-up-delivery.svg"
                                class="card-img-top img-become img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Pick Up & Delivery</h5>
                            <p class="card-text fs-18px">Restaurant</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$9.41</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/cleaning-tools-svg.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">House Cleaning</h5>
                            <p class="card-text fs-18px">Regular</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$22.03 - $44.37</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/tasks/pick-up-delivery.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Pick Up & Delivery</h5>
                            <p class="card-text fs-18px">Restaurant</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$9.41</p>
                        </div>
                    </div>
                </div>

                <div class="col-xxl-3 co-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
                    <div class="card py-2 px-2 border border-success my-3 h-352px-01 m-110px-task">
                        <div class="text-center">
                            <img src="./assets/img/svg/elearning.svg"
                                class="card-img-top img-become w-120px-01 img-fluid" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold fs-20px-task">Tutoring</h5>
                            <p class="card-text fs-18px">High School</p>
                            <p class="card-text text-body-secondary fs-18px">Apr 05, 2021, 09:08 PM</p>
                            <p class="card-text fw-bold fs-18px">$28.83</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <P class="text-center py-3">
                        <button class="rounded-pill text-white bg border fw-medium p-btn fs-18px"
                            data-bs-toggle="tooltip" data-bs-placement="bottom" title="Explore a task">Explore
                            Tasks</button>
                    </P>
                </div>
            </div>

            <div class="row">
                <div class="col-xxl-12 co-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 d-flex justify-content-center">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination my-3">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End -->

    <!-- footer.php -->
    <?php include("inc/footer.php"); ?>


    <!-- script.php -->
    <?php include("inc/script.php"); ?>

</body>

</html>